# IX Sindh Study Hub

A complete starter full-stack study app for Class IX students.

## Stack
- Frontend: HTML, CSS, Vanilla JavaScript
- Backend: Node.js + Express
- Database: SQLite (`better-sqlite3`)
- Auth: JWT + bcryptjs

## Features
- Register/login
- Subjects and chapters
- Notes
- MCQ quiz
- Quiz score history
- Progress tracking
- Admin dashboard for adding notes and questions
- SQLite database created automatically

## Run

1. Install Node.js 20+.
2. Open this folder in VS Code.
3. Run:

```bash
npm install
npm start
```

4. Open:
http://localhost:3000

## Default admin
Email: admin@ixstudy.local
Password: Admin@123

Change the admin password before using the app online.

## API
- POST `/api/auth/register`
- POST `/api/auth/login`
- GET `/api/me`
- GET `/api/subjects`
- GET `/api/subjects/:id/chapters`
- GET `/api/notes`
- GET `/api/questions`
- POST `/api/quizzes/submit`
- GET `/api/progress`
- POST `/api/progress`
- POST `/api/admin/notes`
- POST `/api/admin/questions`

For production, use HTTPS, a strong JWT secret, and a managed database/server.
